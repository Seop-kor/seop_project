package com.one.geoar.advanced.plugins.input;

interface Camera {

    void start();
    void stop();

    int getCameraOrientation();
}
